# C++ fast solve

Compile with optimizations:

```bash
g++ -O2 fast_solve.cpp -o fast_solve
# 1,000,000 kaggle cases in about 60 seconds
# 1,000 extreme cases in about 70 seconds
./fast_solve
```
